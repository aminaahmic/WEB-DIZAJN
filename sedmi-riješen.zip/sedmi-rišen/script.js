
let globalPodaci = [];
let k1_preuzmiDrzave = () => {
    //https://wrd-fit.info/ -> Ispit20240713 -> GetNovePonude

    let url = `https://wrd-fit.info/Ispit20240713/GetNovePonude`
    destinacije.innerHTML = '';//brisemo destinacije
    fetch(url)
        .then(r => {
            if (r.status !== 200) {
                //greska
                return;
            }
            r.json().then(t => {

                let b = 0;
                globalPodaci = t.podaci //setujemo globalnu varijablu

                for (const x of t.podaci) {
                    destinacije.innerHTML += `
                    <div class="destination-card">
                    <img class="destination-img" src="${x.imageUrl}"/>
                    <h2 class="destination-name">${x.drzava}</h2>
                    <div class="destination-date">${x.naredniPolazak.zaDana} | Slobodno mjesta: ${x.naredniPolazak.brojSlobodnihMjesta}</div>
                    <div class="destination-description">
                    ${x.opisPonude}
                    </div>
                    ${prikaziGradovePonude(x)}
                    <button class="destination-button" onclick="k2_odaberiDestinaciju(${b})">K2 Odaberi destinaciju</button>
                  </div>
                    `
                    b++;
                }
            })
        })
}
let dugmePretregae = document.getElementById("button-search");
const popuniInput = (b, x) => {
    destinacije.innerHTML += `
    <div class="destination-card">
    <img class="destination-img" src="${x.imageUrl}"/>
    <h2 class="destination-name">${x.drzava}</h2>
    <div class="destination-date">${x.naredniPolazak.zaDana} | Slobodno mjesta: ${x.naredniPolazak.brojSlobodnihMjesta}</div>
    <div class="destination-description">
    ${x.opisPonude}
    </div>
    ${prikaziGradovePonude(x)}
    <button class="destination-button" onclick="k2_odaberiDestinaciju(${b})">K2 Odaberi destinaciju</button>
  </div>
    `
}
const pretraga = () => {
    let inputPretrage = document.getElementById("naziv").value;
    console.log(globalPodaci);
    destinacije.innerHTML = ``;
    for (let i = 0; i < 6; ++i) {
        let drzavaPretraga = globalPodaci[i].drzava;
        if (drzavaPretraga == inputPretrage) {
            popuniInput(i, globalPodaci[i]);
        }
        for (let j = 0; j < 4; j++) {
            let hotelPretraga = globalPodaci[i].boravakGradovi[j].hotelNaziv;
            let gradPretraga = globalPodaci[i].boravakGradovi[j].nazivGrada;
            if (gradPretraga == inputPretrage || hotelPretraga == inputPretrage) {
                popuniInput(i, globalPodaci[i]);
            }

        }
    }
}


let prikaziGradovePonude = (x) => {
    let s = "<table>";

    for (const g of x.boravakGradovi) {
        s += `<tr>
        <td>${g.nazivGrada}</td>
        <td>${g.hotelNaziv}</td>
        <td>${g.brojNocenja} dana</td>
            
        </tr>`
    }
    s += "</table>"
    return s;
}

let k2_odaberiDestinaciju = (rbDrzave) => {

    let destinacijObj = globalPodaci[rbDrzave];
    drzavaText.value = destinacijObj.drzava;

    let s = "";
    let rbPolaska = 0;
    for (const o of destinacijObj.planiranaPutovanja) {
        s += `
        <tr>
            <td>ID ${o.putovanjeId}</td>
            <td>${o.datumPolaska}</td>
            <td>${o.datumPovratka}</td>
            <td>${o.slobodnaMjestaCount}</td>
            <td>${o.brojDana}</td>
            <td>${o.cijenaPoOsobi} €</td>
            <td><button onclick='K3_odaberiPutovanje(${rbDrzave}, ${rbPolaska}, ${o.putovanjeId})'>K3 Odaberi putovanje</button></td>
        </tr>`
        rbPolaska++;
    }
    putovanjaTabela.innerHTML = s;
}
let nazivDrzavee;
let datumPolaskaa=document.getElementById("datumPolaska");
let cijenaPoOsobii=document.getElementById("cijenaPoGostu");
let global_putovanjeID;
let K3_odaberiPutovanje = (rbDrzave, rbPolaska, putovanjeid) => {
    global_putovanjeID=putovanjeid;
    nazivDrzavee = globalPodaci[rbDrzave].drzava;
     datumPolaskaa = globalPodaci[rbDrzave].planiranaPutovanja[rbPolaska].datumPolaska;
     cijenaPoOsobii = globalPodaci[rbDrzave].planiranaPutovanja[rbPolaska].cijenaPoOsobi;
    console.log(nazivDrzavee, datumPolaskaa, cijenaPoOsobii);
    generisiPromjenuGradova(globalPodaci[rbDrzave].boravakGradovi);
    cijenaPoGostu.value = `${cijenaPoOsobii}`;
    datumPolaska.value = `${datumPolaskaa}`;
    ukupnaCijena.value = `${cijenaPoOsobii}`;
}





let generisiPromjenuGradova = (boravakGradovi) => {
    vrijemeGradova.innerHTML = '';
    b=0;
    for (const o of boravakGradovi) {
        fetch(`http://api.openweathermap.org/data/2.5/weather?q=${o.nazivGrada}&appid=917b026a997320574cd4315b9bf4c73a`)
            .then(
                (response) => {
                    response.json().then((body) => {
                        console.log(body);
                        // Funkciji proslijediti potrebne parametre kako bi se generisali gradovi iz preuzetih podataka
                        generisiGradove(o.nazivGrada, body.wind.speed,body.main.temp,b++);
                        let color=getTempColor(body.main.temp);
                        setTemperaturu(color,b++);
                        setRotaciju(body.wind.deg, b++);
                    })
                }
            )
    }

}
let generisiGradove = (grad,brzina,temperatura,id) => {
    vrijemeGradova.innerHTML += `<div class="city-card">
    <h2 class="city-name">${grad}<h2>
    <div class="city-card-right">
      <div class="wind-vel">
        <span>${brzina}</span>
        <div class="propeller">
        ${generatePropeler(id)}
        </div>
      </div>
      <div class="temp">
        <span>${temperatura}</span>
    ${generateTermometer(id)};
      </div>
    </div>
  </div>`
}
let getTempColor = (temp) => {
    if (temp >= 40)
        return 'red';
    if (temp < 40 && temp >= 30) {
        return 'rgb(235, 100, 52)'
    }
    if (temp < 30 && temp >= 20)
        return 'rgb(235, 134, 52)'
    if (temp < 20 && temp >= 10)
        return 'rgb(235, 211, 52)'
    if (temp < 10 && temp >= 0)
        return 'rgb(52, 235, 116)'
    if (temp < 0)
        return 'rgb(52, 58, 235)'
}
let setRotaciju = (vel, id) => {
    document.getElementById('propeller-' + id).style.animationDuration = `${10 / vel}s`;
}
let setTemperaturu = (color, id) => {
    document.getElementById('path1933-9-9-' + id).style.fill = color;
}

let ErrorBackgroundColor = "#FE7D7D";
let OkBackgroundColor = "#DFF6D8";
let nizGostiju=[];

let posalji = () => {
    //https://wrd-fit.info/ -> Ispit20240713 -> Dodaj

let sviGosti=document.querySelectorAll(".ime-gosta");
sviGosti.forEach((element) => {
    nizGostiju.push(element.value);

});
    let jsObjekat = {
        putovanjeID:global_putovanjeID,
        drzava:nazivDrzavee,
        mobitel:phone.value,
        datumPolaska:datumPolaskaa,
        cijenaUkupno:ukupnaCijena.value,
        gostiPutovanja: nizGostiju,
        brojIndeksa:brojIndeksa.value,
        email:email.value,
        datumVazenjaPasosa:datumVazenjaPasosa.value,
      };

    let jsonString = JSON.stringify(jsObjekat);

    console.log(jsObjekat);

    let url = "https://wrd-fit.info/Ispit20240713/Dodaj";

    //fetch tipa "POST" i saljemo "jsonString"
    fetch(url, {
        method: "POST",
        body: jsonString,
        headers: {
            "Content-Type": "application/json",
        }
    })
        .then(r => {
            if (r.status != 200) {
                alert("Greška")
                return;
            }

            r.json().then(t => {

                if (t.idRezervacije != null && Number(ukupnaCijena.value) > 0) {
                    dialogSuccess(`Idi na placanje rezervacije broj ${t.idRezervacije} - iznos ${ukupnaCijena.value} EUR`, () => {
                        window.location = `https://www.paypal.com/cgi-bin/webscr?business=adil.joldic@yahoo.com&cmd=_xclick&currency_code=EUR&amount=${ukupnaCijena.value}&item_name=Dummy invoice`
                    });
                }
            })

        })
}
let broj_gost = document.getElementById("brojGostiju");

let ukupno = () => {
    if (cijenaPoGostu.value === "") {
        return;
    }
    ukupnaCijena.value = cijenaPoGostu.value * brojGostiju.value;
}
let promjenaBrojaGostiju = () => {
    let vrijednostGosta=broj_gost.value;
    gosti.innerHTML = "";
    ukupno();
    for (let i = 0; i < brojGostiju.value; ++i) {
        gosti.innerHTML += `
<div>
<label for="gost-broj-${i}">Ime gosta ${i + 1}</label>
<input type="text" class="ime-gosta" id="gost-broj-${i}" oninput="provjeriGosta(${i})"/>
          </div>
`;
    }
}

promjenaBrojaGostiju();

let provjeriGosta = (index) => {
    let r = /^[A-Z][a-z]{1,}\s[A-Z][a-z]{1,}$/;
    let inputGosta = document.getElementById(`gost-broj-${index}`)
    if (!r.test(inputGosta.value)) {
        inputGosta.style.backgroundColor = ErrorBackgroundColor;
    }
    else {
        inputGosta.style.backgroundColor = OkBackgroundColor;
    }
}
let provjeriTelefon = () => {
    let r = /^\+[0-9]{3}-[0-9]{2}-[0-9]{3}-[0-9]{3}$/;
    if (!r.test(phone.value)) {
        phone.style.backgroundColor = ErrorBackgroundColor;
    }
    else {
        phone.style.backgroundColor = OkBackgroundColor;
    }
}

let provjeriBrojIndeksa = () => {
    let r = /^IB[0-9]{6}$/;
    if (!r.test(brojIndeksa.value)) {
        brojIndeksa.style.backgroundColor = ErrorBackgroundColor;
    }
    else {
        brojIndeksa.style.backgroundColor = OkBackgroundColor;
    }
}
let provjeriEmail = () => {
    let r = /^[a-z]+\.[a-z]+@(fit.ba|edu.fit.ba)$/;
    if (!r.test(email.value)) {
        email.style.backgroundColor = ErrorBackgroundColor;
    }
    else {
        email.style.backgroundColor = OkBackgroundColor;
    }
}

let provjeriDatumPasos = () => {
    let r = /^(0[1-9]|[12][0-9]|3[01])\.(0[1-9]|1[0-2])\.(19|20)\d{2}$/;

    if (!r.test(datumVazenjaPasosa.value)) {
        datumVazenjaPasosa.style.backgroundColor = ErrorBackgroundColor;
    }
    else {
        datumVazenjaPasosa.style.backgroundColor = OkBackgroundColor;
    }
}
k1_preuzmiDrzave();