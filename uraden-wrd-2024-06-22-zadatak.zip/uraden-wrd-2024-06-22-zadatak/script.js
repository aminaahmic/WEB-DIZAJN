const gradIliDrzavaInput = document.querySelector(".grad-ili-drzava-input");

let globalPodaci = [];
let k1_preuzmiDrzave = () => {
    //https://wrd-fit.info/ -> Ispit20240622 -> GetPonuda

    let url = `https://wrd-fit.info/Ispit20240622/GetNovePonude`;
    destinacije.innerHTML = ""; //brisemo destinacije
    fetch(url).then((r) => {
        if (r.status !== 200) {
            //greska
            return;
        }
        r.json().then((t) => {
            console.log(t);
            let b = 0;
            const drzavaIliGrad = gradIliDrzavaInput.value;

            const findFunction = (grad) => grad.nazivGrada === drzavaIliGrad;
            const filterFunction = (podatak) =>
                podatak.drzava === drzavaIliGrad ||
                podatak.boravakGradovi.find(findFunction);

            globalPodaci = t.podaci.filter(filterFunction);

            for (const x of globalPodaci) {
                destinacije.innerHTML += `
                     <div class="col-md-4 col-sm-6 col-xs-12 drzava" style="margin-bottom:40px">
                    <div class="featured-item">
                        <div class="thumb">
                            <img src="${x.imageUrl}" alt="">
                            
                            <div class="date-content">
                                <h6>${x.naredniPolazak.zaDana}</h6>
                                <span>dana</span>
                            </div>
                        </div>
                        <div class="down-content">
                            <h4>${x.drzava}</h4>
                            <span>${
                                x.naredniPolazak.datumPolaska
                            } | Slobodno mjesta: ${
                    x.naredniPolazak.brojSlobodnihMjesta
                } </span>
                            <p>${x.opisPonude}</p>
                            <p>${prikaziGradove(x)}</p>
                            <div class="row">
                                <div class="text-button">
                                    <button onclick="k2_odaberiDestinaciju(${b})">Odaberi destinaciju</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                    `;
                b++;
            }
        });
    });
};

let prikaziGradove = (x) => {
    let s = "<table style='width:100%; '>";

    for (const g of x.boravakGradovi) {
        s += `<tr>
        <td>${g.nazivGrada}</td>
        <td>${g.hotelNaziv}</td>
        <td>${g.brojNocenja} dana</td>
            
        </tr>`;
    }
    s += "</table>";
    return s;
};

let k2_odaberiDestinaciju = (rbDrzave) => {
    let destinacijObj = globalPodaci[rbDrzave];
    drzavaText.value = destinacijObj.drzava;

    drzavaSpan.innerHTML = destinacijObj.drzava;

    let s = "";
    let rbPolaska = 0;
    for (const o of destinacijObj.planiranaPutovanja) {
        s += `
        <tr>
            <td>ID ${o.id}</td>
            <td>${o.datumPolaska}</td>
            <td>${o.datumPovratka}</td>
            <td>${o.brojSlobodnihMjesta}</td>
            <td>${o.brojDana}</td>
            <td>${o.cijenaPoOsobiEUR} €</td>
            <td><button onclick="popuniInpute(${o.id}, '${o.datumPolaska}', ${o.cijenaPoOsobiEUR})">K3 Odaberi putovanje</button></td>
        </tr>`;
        rbPolaska++;
    }
    putovanjaTabela.innerHTML = s;
};

const calcSumarnoZaSveGoste = () => {
    if (cijenaPoGostu.value === "") {
        return;
    }

    ukupnaCijena.value = cijenaPoGostu.value * brojGostiju.value;
};

let putovanjeID = null;
const popuniInpute = (putovanjeIDVal, datumPolaskaVal, cijenaPoGostuVal) => {
    putovanjeID = putovanjeIDVal;
    datumPolaska.value = datumPolaskaVal;
    cijenaPoGostu.value = cijenaPoGostuVal;

    calcSumarnoZaSveGoste();
};

let ErrorBackgroundColor = "#FE7D7D";
let OkBackgroundColor = "#DFF6D8";

let posalji = () => {
    //https://wrd-fit.info/ -> Ispit20240622 -> Dodaj

    let jsObjekat = {
        putovanjeID: String(putovanjeID),
        drzava: drzavaText.value,
        mobitel: phone.value,
        datumPolaska: datumPolaska.value,
        gostiPutovanja: getAllGostiNames(),
        brojIndeksa: brojIndeksa.value,
    };

    let jsonString = JSON.stringify(jsObjekat);

    console.log(jsObjekat);

    let url = "https://wrd-fit.info/Ispit20240622/Dodaj";

    //fetch tipa "POST" i saljemo "jsonString"
    fetch(url, {
        method: "POST",
        body: jsonString,
        headers: {
            "Content-Type": "application/json",
        },
    }).then((r) => {
        if (r.status != 200) {
            alert("Greška");
            return;
        }

        r.json().then((t) => {
            //28.06.2024. naknadni komentar: umjesto "t.idRezervacije>0" sada je "t.idRezervacije.length>0"
            //jer idRezervacije nije brojčani podatak, već string
            if (t.idRezervacije.length > 0 && Number(ukupnaCijena.value) > 0) {
                //28.06.2024. naknadni komentar: sada su dodati JS i CSS fajlovi za dialogSuccess
                //alternativa dialogu je JS alert
                dialogSuccess(
                    `Idi na placanje rezervacije broj ${t.idRezervacije} - iznos ${ukupnaCijena.value} EUR`,
                    () => {
                        window.location = `https://www.paypal.com/cgi-bin/webscr?business=adil.joldic@yahoo.com&cmd=_xclick&currency_code=EUR&amount=${ukupnaCijena.value}&item_name=Dummy invoice`;
                    }
                );
            }
        });
    });
};

const azurirajGostiInput = () => {
    gosti.innerHTML = "";

    for (let i = 0; i < brojGostiju.value; ++i) {
        gosti.innerHTML += `
            <div>
                <label for="gost-broj-${i}">Ime gosta ${i + 1}</label>
                <input type="text" class="ime-gosta" id="gost-broj-${i}" oninput="provjeriGosta(${i})">
            </div>
        `;
    }
};
azurirajGostiInput();

const getAllGostiNames = () => {
    const gostiNames = [];
    const gostiInputs = document.querySelectorAll(".ime-gosta");

    for (const gostInput of gostiInputs) {
        const gostName = gostInput.value;

        gostiNames.push(gostName);
    }

    return gostiNames;
};

let promjenaBrojaGostiju = () => {
    azurirajGostiInput();
    calcSumarnoZaSveGoste();
};

let provjeriGosta = (index) => {
    const gostInput = document.getElementById(`gost-broj-${index}`);

    if (gostInput === undefined) {
        return;
    }

    let r = /^[a-zA-Z]{2,}\s[a-zA-Z]{2,}$/;
    if (!r.test(gostInput.value)) {
        gostInput.style.backgroundColor = ErrorBackgroundColor;
    } else {
        gostInput.style.backgroundColor = OkBackgroundColor;
    }
};

let provjeriTelefon = () => {
    let r = /^\+\d{3}-\d{2}-\d{3}-\d{3}$/;
    if (!r.test(phone.value)) {
        phone.style.backgroundColor = ErrorBackgroundColor;
    } else {
        phone.style.backgroundColor = OkBackgroundColor;
    }
};

let provjeriBrojIndeksa = () => {
    let r = /^IB[0-9]{6}$/;
    if (!r.test(brojIndeksa.value)) {
        brojIndeksa.style.backgroundColor = ErrorBackgroundColor;
    } else {
        brojIndeksa.style.backgroundColor = OkBackgroundColor;
    }
};

k1_preuzmiDrzave();
